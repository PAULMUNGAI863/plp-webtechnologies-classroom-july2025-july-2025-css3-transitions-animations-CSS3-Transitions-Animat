// Part 2: JavaScript Functions — Scope, Parameters & Return Values

// Global variable
let globalCount = 0;

// Function with parameter & return value
function addNumbers(a, b) {
  let result = a + b; // local variable
  return result;
}

// Function to toggle animation on box
function toggleAnimation(elementId) {
  const element = document.getElementById(elementId);
  element.classList.toggle("animate");
}

// Function to show modal
function showModal(id) {
  document.getElementById(id).classList.add("show");
}

// Function to hide modal
function hideModal(id) {
  document.getElementById(id).classList.remove("show");
}

// Function demonstrating scope manipulation
function incrementGlobalCount() {
  globalCount++;
  return globalCount;
}

// Part 3: Combining CSS Animations with JavaScript

document.getElementById("animateBtn").addEventListener("click", function() {
  toggleAnimation("box");
  const count = incrementGlobalCount();
  console.log("Button clicked " + count + " times");
  
  if (count % 3 === 0) { // every 3rd click, show modal
    showModal("modal");
  }
});

document.getElementById("closeModal").addEventListener("click", function() {
  hideModal("modal");
});

// Example function usage
console.log("Sum of 5 + 10 = " + addNumbers(5,10));